Inheritance provides the ability to write code once and use it in many different locations
It also adds a few design options and considerations
